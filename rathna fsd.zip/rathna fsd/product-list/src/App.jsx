import { useState } from "react";
import Navbar from "./components/Navbar";
import SearchBar from "./components/SearchBar";
import FilterSort from "./components/FilterSort";
import ProductList from "./components/ProductList";
import products from "./data/products";
import "./App.css";

function App() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [sortBy, setSortBy] = useState("default");

  // Search and Category Filter
  let filteredProducts = products.filter((product) => {
    const matchesSearch = product.name
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesCategory =
      category === "All" || product.category === category;

    return matchesSearch && matchesCategory;
  });

  // Sorting
  if (sortBy === "priceLow") {
    filteredProducts.sort((a, b) => a.price - b.price);
  }

  if (sortBy === "priceHigh") {
    filteredProducts.sort((a, b) => b.price - a.price);
  }

  if (sortBy === "ratingHigh") {
    filteredProducts.sort((a, b) => b.rating - a.rating);
  }

  // Add to Cart
  const handleAddToCart = (product) => {
    console.log("Added to Cart:", product.name);
  };

  return (
    <div>
      <Navbar />

      <header className="header">
        <h1>Product Listing</h1>
        <p>Find your favorite products</p>
      </header>

      <main className="container">
        <div className="controls">
          <SearchBar
            search={search}
            setSearch={setSearch}
          />

          <FilterSort
            category={category}
            setCategory={setCategory}
            sortBy={sortBy}
            setSortBy={setSortBy}
          />
        </div>

        <ProductList
          products={filteredProducts}
          onAddToCart={handleAddToCart}
        />
      </main>
    </div>
  );
}

export default App;