function FilterSort({
  category,
  setCategory,
  sortBy,
  setSortBy
}) {
  return (
    <div className="filter-sort-container">

      {/* Category Filter */}
      <select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
      >
        <option value="All">All Categories</option>
        <option value="Electronics">Electronics</option>
        <option value="Clothing">Clothing</option>
        <option value="Footwear">Footwear</option>
        <option value="Bags">Bags</option>
        <option value="Books">Books</option>
      </select>

      {/* Sorting */}
      <select
        value={sortBy}
        onChange={(e) => setSortBy(e.target.value)}
      >
        <option value="default">Sort By</option>
        <option value="priceLow">Price: Low to High</option>
        <option value="priceHigh">Price: High to Low</option>
        <option value="ratingHigh">Rating: High to Low</option>
      </select>

    </div>
  );
}

export default FilterSort;