function Navbar() {
  return (
    <nav className="navbar">
      <div className="logo">Product List</div>

      <div className="nav-links">
        <a href="#home">Home</a>
        <a href="#products">Products</a>
        <a href="#cart">Cart</a>
      </div>
    </nav>
  );
}

export default Navbar;