const products = [
  {
    id: 1,
    name: "Laptop",
    price: 50000,
    category: "Electronics",
    rating: 4.5,
    image: "images/laptop.webp"
  },
  {
    id: 2,
    name: "Headphones",
    price: 2000,
    category: "Electronics",
    rating: 4.0,
    image: "images/headphone.jpg"
  },
  {
    id: 3,
    name: "Smart Watch",
    price: 3500,
    category: "Electronics",
    rating: 4.3,
    image: "images/watch.jpg"
  },
  {
    id: 4,
    name: "T-Shirt",
    price: 800,
    category: "Clothing",
    rating: 4.2,
    image: "images/tshirt.avif"
  },
  {
    id: 5,
    name: "Jeans",
    price: 1500,
    category: "Clothing",
    rating: 4.1,
    image: "images/jeans.avif"
  },
  {
    id: 6,
    name: "Running Shoes",
    price: 2500,
    category: "Footwear",
    rating: 4.7,
    image: "images/shoes.webp"
  },
  {
    id: 7,
    name: "School Bag",
    price: 1200,
    category: "Bags",
    rating: 4.4,
    image: "images/bag.png"
  },
  {
    id: 8,
    name: "Novel Book",
    price: 500,
    category: "Books",
    rating: 4.6,
    image: "images/novel.avif"
  }
];

export default products;